package com.example.day12_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day12DemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
